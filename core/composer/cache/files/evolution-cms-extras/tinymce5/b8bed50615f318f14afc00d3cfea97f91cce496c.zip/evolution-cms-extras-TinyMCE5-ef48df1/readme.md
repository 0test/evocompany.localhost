# TinyMCE 5 for Evolution CMS 3

## Install by artisan Extras:

run in you /core/ folder:

```php artisan extras extras TinyMCE5 master```

you can set any version, not only **master**


## Install by artisan package installer: 

run in you /core/ folder:

```php artisan package:installrequire evolution-cms-extras/tinymce5 "*"```


## Custom config

You can add own config in folder: assets/plugins/tinymce5/configs
And after that set new config in System setting



